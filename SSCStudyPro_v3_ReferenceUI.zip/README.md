# SSC StudyPro v2.0

Personal Android study app for Std X SSC.

Included:
- Dark StudyPro-style UI with custom study logo
- I Unit Test marked OVER
- All supplied subject portions, including Sanskrit Composite
- Individual chapter/topic checkboxes
- Portion-based study completion percentages
- Exam marks entry
- Progress/analysis screen
- 1-hour persistent study timer using wall-clock time
- Break after the timer ends until the next manual start
- Timer notification + bundled distinctive sound
- Hourly motivation notifications
- Flexible weekly study plan with Maths every day for 60 minutes
- Next exam/date editor
- Browser search for Model English School Dombivli East SSC timetable
- Subject study tips
- Maths Hub + calculator

The app does not invent school exam dates. The browser search and Next Exam editor are provided for the user's future timetable updates.

English grammar/writing is kept at the exact level shown in the uploaded school portion pages ("Textual") where individual topics were not listed.


## UI v3
Updated the programmatic Android UI to closely follow the supplied StudyPro reference: dark navy cards, compact chips, dashboard grid, timer ring, syllabus cards, exam cards, study plan, progress, reminders, and settings layouts.
