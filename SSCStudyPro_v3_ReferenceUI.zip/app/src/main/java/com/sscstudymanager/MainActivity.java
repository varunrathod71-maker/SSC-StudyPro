package com.sscstudymanager;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, content, nav;
    ScrollView scroll;
    android.content.SharedPreferences sp;

    static final int NAVY=Color.rgb(4,15,34);
    static final int PANEL=Color.rgb(10,29,54);
    static final int PANEL2=Color.rgb(13,38,70);
    static final int BLUE=Color.rgb(27,105,255);
    static final int BLUE2=Color.rgb(70,137,255);
    static final int CYAN=Color.rgb(45,205,235);
    static final int PURPLE=Color.rgb(132,82,235);
    static final int GREEN=Color.rgb(35,205,120);
    static final int ORANGE=Color.rgb(245,174,45);
    static final int RED=Color.rgb(245,75,90);
    static final int WHITE=Color.rgb(245,248,255);
    static final int MUTED=Color.rgb(145,165,195);
    static final int LINE=Color.rgb(31,61,96);

    static final String[] SUBJECTS={
        "English","Marathi","Hindi","Sanskrit Composite",
        "Mathematics I","Mathematics II","Science I","Science II",
        "History","Political Science","Geography",
        "Health & Physical Education","M.C.C.","Self-Defence Studies","Water Security"
    };

    static final Map<String,String[][]> PORTION=new LinkedHashMap<>();
    static {
        PORTION.put("English",new String[][]{
            {"I Unit Test","Unit 1","Grammar: Textual"},
            {"I Term","Unit 1","Unit 2","Grammar: Textual","Writing Skill: Textual"},
            {"Prelims","Unit 1","Unit 2","Unit 3","Unit 4","Grammar: Textual","Writing Skill: Textual"}});
        PORTION.put("Marathi",new String[][]{
            {"I Unit Test","भाग 1","पाठाखालील व्याकरण","भाषाभ्यास","शब्दसंपत्ती","विरामचिन्हे"},
            {"I Term","भाग 1","भाग 2","पाठाखालील व्याकरण","भाषाभ्यास","शब्दसंपत्ती","विरामचिन्हे","वाक्य रूपांतर","निबंध लेखन","सारांश लेखन","पत्र लेखन","कथालेखन","बातमीलेखन","जाहिरात लेखन"},
            {"Prelims","भाग 1","भाग 2","भाग 3","भाग 4","प्रथम सत्राप्रमाणे संपूर्ण पाठाखालील व्याकरण","प्रथम सत्राप्रमाणे उपयोजित लेखन"}});
        PORTION.put("Hindi",new String[][]{
            {"I Unit Test","पाठ 1","पाठ 2","पाठ 3","पाठ 4","पाठों के आधार पर","काल","संधि","मुहावरे","अव्यय"},
            {"I Term","पाठ 1–7","दूसरी इकाई पाठ 1–4","सम्पूर्ण पाठ्यपुस्तक के आधार पर व्याकरण","निबंध","पत्र (औपचारिक/अनौपचारिक)","कहानी","आकलन","विज्ञापन"},
            {"Prelims","सम्पूर्ण पाठ्यपुस्तक (पहली + दूसरी इकाई)","सम्पूर्ण पाठ्यपुस्तक / SSC pattern","निबंध","पत्र (औपचारिक/अनौपचारिक)","कहानी","आकलन","विज्ञापन"}});
        PORTION.put("Sanskrit Composite",new String[][]{
            {"I Unit Test","Lesson 1","Lesson 2","Lesson 3"},
            {"I Term","Lesson 1","Lesson 2","Lesson 3","Lesson 4","Lesson 5","Lesson 6","Lesson 7","अभ्यासपत्रम् 1","अभ्यासपत्रम् 2","समासाः","धातुसाधित विशेषणानि","निजन्ता","संख्याविशेषम्"},
            {"Prelims","Lesson 1","Lesson 2","Lesson 3","Lesson 4","Lesson 5","Lesson 6","Lesson 7","Lesson 8","Lesson 9","Lesson 10","Lesson 11","अभ्यासपत्रम् 1","अभ्यासपत्रम् 2","अभ्यासपत्रम् 3","अभ्यासपत्रम् 4"}});
        PORTION.put("Mathematics I",new String[][]{
            {"I Unit Test","2. Quadratic Equations","5. Probability"},
            {"I Term","1. Linear Equations in Two Variables","2. Quadratic Equations","3. Arithmetic Progression","5. Probability"},
            {"Prelims","1. Real Numbers","2. Quadratic Equations","3. Arithmetic Progression","4. Financial Planning","5. Probability","6. Statistics"}});
        PORTION.put("Mathematics II",new String[][]{
            {"I Unit Test","1. Similarity","2. Pythagoras Theorem"},
            {"I Term","1. Similarity","2. Pythagoras Theorem","3. Circle","5. Co-ordinate Geometry","6. Trigonometry"},
            {"Prelims","1. Similarity","2. Pythagoras Theorem","3. Circle","4. Geometric Constructions","5. Co-ordinate Geometry","6. Trigonometry","7. Mensuration"}});
        PORTION.put("Science I",new String[][]{
            {"I Unit Test","Lesson 2","Lesson 3","Lesson 8"},
            {"I Term","Lesson 2","Lesson 3","Lesson 4","Lesson 5","Lesson 8"},
            {"Prelims","Lesson 1","Lesson 2","Lesson 3","Lesson 4","Lesson 5","Lesson 6","Lesson 7","Lesson 8","Lesson 9","Lesson 10"}});
        PORTION.put("Science II",new String[][]{
            {"I Unit Test","Lesson 1","Lesson 6"},
            {"I Term","Lesson 1","Lesson 2","Lesson 3","Lesson 4","Lesson 5","Lesson 6","Lesson 10"},
            {"Prelims","Lesson 1","Lesson 2","Lesson 3","Lesson 4","Lesson 5","Lesson 6","Lesson 7","Lesson 8","Lesson 9","Lesson 10"}});
        PORTION.put("History",new String[][]{
            {"I Unit Test","Lesson 1","Lesson 2"},
            {"I Term","Lesson 1","Lesson 2","Lesson 3","Lesson 4","Lesson 5"},
            {"Prelims","Lesson 1","Lesson 2","Lesson 3","Lesson 4","Lesson 5","Lesson 6","Lesson 7","Lesson 8","Lesson 9"}});
        PORTION.put("Political Science",new String[][]{
            {"I Unit Test","Lesson 1","Lesson 2"},
            {"I Term","Lesson 1","Lesson 2","Lesson 3"},
            {"Prelims","Lesson 1","Lesson 2","Lesson 3","Lesson 4","Lesson 5"}});
        PORTION.put("Geography",new String[][]{
            {"I Unit Test","Lesson 1","Lesson 2","Lesson 3"},
            {"I Term","Lesson 1","Lesson 2","Lesson 3","Lesson 4","Lesson 5"},
            {"Prelims","Lesson 1","Lesson 2","Lesson 3","Lesson 4","Lesson 5","Lesson 6","Lesson 7","Lesson 8","Lesson 9"}});
        PORTION.put("Health & Physical Education",new String[][]{
            {"I Term","Sit & Reach","Pushups","Standing Broad Jump","Standing ball throw","Kho-Kho","Daily observation, Personal health & Hygiene"},
            {"II Term","Sit & Reach","Wall Volley","Pushups","Sitting Ball Throw","Kho-Kho","Daily observation, Personal health & Hygiene"}});
        PORTION.put("M.C.C.",new String[][]{
            {"I Term","March Past","Kadam Taal","Savadhan","Vishram","Left Turn","Right Turn"},
            {"II Term","March Past","Kadam Taal","Savadhan","Vishram","Left Turn","Right Turn"}});
        PORTION.put("Self-Defence Studies",new String[][]{
            {"I Term","Lesson 1","Lesson 2","Lesson 3"},{"II Term","Lesson 4","Lesson 5","Lesson 6"}});
        PORTION.put("Water Security",new String[][]{
            {"I Term","Unit 1","Unit 2"},{"II Term","Unit 3","Unit 4"}});
    }

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        getWindow().setStatusBarColor(NAVY);
        getWindow().setNavigationBarColor(NAVY);
        sp=getSharedPreferences("data",0);
        buildShell();
        showHome();
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS")!=0)
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"},55);
    }

    int dp(float x){return (int)(x*getResources().getDisplayMetrics().density+.5f);}
    TextView text(String s,float size,int color){
        TextView t=new TextView(this); t.setText(s); t.setTextColor(color); t.setTextSize(size);
        t.setFontFeatureSettings("kern"); return t;
    }
    TextView label(String s,float size){TextView t=text(s,size,WHITE);t.setPadding(dp(2),dp(2),dp(2),dp(2));return t;}
    GradientDrawable bg(int color,float radius){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dp(radius));return g;}
    GradientDrawable stroke(int fill,int line,float radius){GradientDrawable g=bg(fill,radius);g.setStroke(dp(1),line);return g;}
    View spacer(int h){Space s=new Space(this);s.setLayoutParams(new LinearLayout.LayoutParams(1,dp(h)));return s;}

    TextView clickable(String s,int size,int fill){
        TextView v=text(s,size,WHITE);v.setGravity(Gravity.CENTER);v.setPadding(dp(12),dp(9),dp(12),dp(9));
        v.setBackground(bg(fill,18));v.setClickable(true);v.setFocusable(true);
        return v;
    }
    LinearLayout card(){
        LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(dp(14),dp(12),dp(14),dp(12));
        l.setBackground(stroke(PANEL,LINE,18));return l;
    }
    void add(LinearLayout parent,View v,int h){parent.addView(v,new LinearLayout.LayoutParams(-1,dp(h)));}
    void addGap(int h){content.addView(spacer(h));}

    void buildShell(){
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(NAVY);
        scroll=new ScrollView(this);scroll.setFillViewport(true);
        content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(16),dp(10),dp(16),dp(94));scroll.addView(content);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));

        nav=new LinearLayout(this);nav.setPadding(dp(8),dp(5),dp(8),dp(4));nav.setGravity(Gravity.CENTER);
        nav.setBackgroundColor(Color.rgb(6,24,47));
        String[] icons={"⌂","✓","▤","▣","•••"};
        String[] names={"Home","Plan","Syllabus","Exams","More"};
        for(int i=0;i<5;i++){
            final int k=i;
            LinearLayout item=new LinearLayout(this);item.setOrientation(LinearLayout.VERTICAL);item.setGravity(Gravity.CENTER);
            TextView ic=text(icons[i],18,WHITE);ic.setGravity(Gravity.CENTER);
            TextView nm=text(names[i],10,MUTED);nm.setGravity(Gravity.CENTER);
            item.addView(ic,new LinearLayout.LayoutParams(-1,dp(24)));item.addView(nm,new LinearLayout.LayoutParams(-1,dp(19)));
            item.setOnClickListener(v->{if(k==0)showHome();else if(k==1)showPlan();else if(k==2)showSyllabus();else if(k==3)showExams();else showMore();});
            nav.addView(item,new LinearLayout.LayoutParams(0,dp(63),1));
        }
        root.addView(nav,new LinearLayout.LayoutParams(-1,dp(70)));
        setContentView(root);
    }

    void head(String title){
        content.removeAllViews();
        LinearLayout bar=new LinearLayout(this);bar.setGravity(Gravity.CENTER_VERTICAL);
        TextView back=clickable("‹",28,Color.TRANSPARENT);back.setPadding(0,0,0,0);
        back.setOnClickListener(v->showHome());
        bar.addView(back,new LinearLayout.LayoutParams(dp(40),dp(48)));
        TextView t=label(title,20);t.setTypeface(null,1);bar.addView(t,new LinearLayout.LayoutParams(0,dp(48),1));
        TextView more=label("⋮",23);more.setGravity(Gravity.CENTER);bar.addView(more,new LinearLayout.LayoutParams(dp(32),dp(48)));
        content.addView(bar);
    }

    String[] exams(){return new String[]{"I Unit Test","I Term","Prelims"};}
    ArrayList<String> items(String sub,String exam){
        ArrayList<String>a=new ArrayList<>();String[][] arr=PORTION.get(sub);if(arr==null)return a;
        for(String[] row:arr)if(row[0].equals(exam))for(int i=1;i<row.length;i++)a.add(row[i]);return a;
    }
    String key(String s,String e,String i){return "done_"+s+"_"+e+"_"+i;}
    int doneCount(String s,String e){int c=0;for(String i:items(s,e))if(sp.getBoolean(key(s,e,i),false))c++;return c;}
    int subjectPct(String s,String e){ArrayList<String>a=items(s,e);return a.isEmpty()?0:doneCount(s,e)*100/a.size();}
    int pct(String e){int d=0,t=0;for(String s:SUBJECTS){ArrayList<String>a=items(s,e);t+=a.size();d+=doneCount(s,e);}return t==0?0:d*100/t;}
    String formatStudy(){long m=sp.getLong("studyMinutes",0);return (m/60)+"h "+(m%60)+"m";}

    TextView chip(String s,boolean active){
        TextView v=clickable(s,10,active?BLUE:PANEL2);v.setPadding(dp(14),dp(7),dp(14),dp(7));return v;
    }

    void showHome(){
        content.removeAllViews();
        LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout user=new LinearLayout(this);user.setOrientation(LinearLayout.VERTICAL);
        TextView hello=label("Good Morning,\nStudent 👋",16);hello.setTypeface(null,1);user.addView(hello);
        user.addView(text("Keep going! You're doing great!",11,MUTED));
        top.addView(user,new LinearLayout.LayoutParams(0,dp(60),1));
        TextView gear=clickable("⚙",20,PANEL);gear.setOnClickListener(v->showMore());top.addView(gear,new LinearLayout.LayoutParams(dp(46),dp(46)));
        content.addView(top);addGap(12);

        LinearLayout stats=new LinearLayout(this);
        stat(stats,"Today's\nStudy",formatStudy(),CYAN);
        stat(stats,"Unit Test","OVER",PURPLE);
        stat(stats,"Streak","5 days",ORANGE);
        content.addView(stats);addGap(15);

        TextView qa=label("Quick Actions",17);qa.setTypeface(null,1);content.addView(qa);addGap(8);
        String[][] q={{"⏱","Study Timer","timer"},{"▣","My Plan","plan"},{"▤","Syllabus","syll"},{"▥","Exams","exam"},{"▦","Timetable","exam"},{"•••","More","more"}};
        for(int r=0;r<3;r++){
            LinearLayout row=new LinearLayout(this);
            for(int c=0;c<2;c++){
                int ix=r*2+c;LinearLayout b=action(q[ix][0],q[ix][1]);
                final String id=q[ix][2];b.setOnClickListener(v->{if(id.equals("timer"))showTimer();else if(id.equals("plan"))showPlan();else if(id.equals("syll"))showSyllabus();else if(id.equals("exam"))showExams();else showMore();});
                row.addView(b,new LinearLayout.LayoutParams(0,dp(82),1));if(c==0)((LinearLayout.LayoutParams)b.getLayoutParams()).setMargins(0,0,dp(8),dp(8));
            }content.addView(row);
        }
        LinearLayout mot=card();TextView mt=label("🏔  Motivation",13);mt.setTypeface(null,1);mot.addView(mt);
        mot.addView(text("\"Discipline today builds the freedom\nyou want tomorrow.\"",13,WHITE));
        mot.addView(text("Keep going, you're doing great!",10,MUTED));
        content.addView(mot,new LinearLayout.LayoutParams(-1,dp(108)));addGap(8);
    }

    void stat(LinearLayout row,String title,String value,int accent){
        LinearLayout c=card();TextView a=text(title,10,MUTED);c.addView(a);TextView v=label(value,16);v.setTypeface(null,1);c.addView(v);
        View line=new View(this);line.setBackgroundColor(accent);c.addView(line,new LinearLayout.LayoutParams(-1,dp(3)));
        row.addView(c,new LinearLayout.LayoutParams(0,dp(92),1));if(row.getChildCount()>1)((LinearLayout.LayoutParams)c.getLayoutParams()).setMargins(dp(5),0,0,0);
    }
    LinearLayout action(String icon,String name){
        LinearLayout l=card();l.setGravity(Gravity.CENTER_VERTICAL);l.setOrientation(LinearLayout.HORIZONTAL);
        TextView i=label(icon,22);i.setGravity(Gravity.CENTER);l.addView(i,new LinearLayout.LayoutParams(dp(44),-1));
        TextView n=label(name,12);n.setGravity(Gravity.CENTER_VERTICAL);l.addView(n,new LinearLayout.LayoutParams(0,-1,1));return l;
    }

    void showTimer(){
        head("Study Timer");
        LinearLayout tabs=new LinearLayout(this);String[] ts={"Pomodoro","Custom","Focus"};for(int i=0;i<3;i++){TextView c=chip(ts[i],i==0);tabs.addView(c,new LinearLayout.LayoutParams(0,dp(38),1));if(i>0)((LinearLayout.LayoutParams)c.getLayoutParams()).setMargins(dp(5),0,0,0);}content.addView(tabs);addGap(18);
        LinearLayout p=card();RingView ring=new RingView(this);ring.setValue(25);p.setGravity(Gravity.CENTER);p.addView(ring,new LinearLayout.LayoutParams(dp(220),dp(220)));content.addView(p,new LinearLayout.LayoutParams(-1,dp(260)));addGap(12);
        LinearLayout controls=new LinearLayout(this);TextView reset=clickable("↻",22,PANEL2);TextView play=clickable("▶",22,BLUE);TextView settings=clickable("⚙",20,PANEL2);
        controls.addView(reset,new LinearLayout.LayoutParams(dp(52),dp(52)));controls.addView(play,new LinearLayout.LayoutParams(dp(64),dp(64)));((LinearLayout.LayoutParams)play.getLayoutParams()).setMargins(dp(28),0,dp(28),0);controls.addView(settings,new LinearLayout.LayoutParams(dp(52),dp(52)));controls.setGravity(Gravity.CENTER);content.addView(controls);
        LinearLayout focus=card();TextView ft=label("Focus Mode",14);ft.setTypeface(null,1);focus.addView(ft);focus.addView(text("Block distractions (other apps)",10,MUTED));Switch sw=new Switch(this);sw.setChecked(true);focus.addView(sw,new LinearLayout.LayoutParams(-1,dp(35)));content.addView(focus);
        final TextView hidden=label("01:00:00",1);hidden.setVisibility(View.GONE);content.addView(hidden);
        Runnable update=new Runnable(){public void run(){long end=sp.getLong("timerEnd",0),left=end-System.currentTimeMillis();if(end>0&&left>0){ring.setSeconds(left/1000);ring.invalidate();ring.postDelayed(this,1000);}else if(end>0){ring.setSeconds(0);sp.edit().remove("timerEnd").apply();Toast.makeText(MainActivity.this,"Study hour complete — take a break!",Toast.LENGTH_LONG).show();}else{ring.setSeconds(3600);ring.invalidate();}}};
        play.setOnClickListener(v->{long end=System.currentTimeMillis()+3600000L;sp.edit().putLong("timerEnd",end).apply();scheduleTimer(end);update.run();});
        reset.setOnClickListener(v->{sp.edit().remove("timerEnd").apply();cancelTimer();ring.setSeconds(3600);ring.invalidate();});
        update.run();
    }

    static class RingView extends View{
        Paint p=new Paint(3);long seconds=1500;int max=3600;
        RingView(Context c){super(c);p.setStrokeCap(Paint.Cap.ROUND);}
        void setSeconds(long s){seconds=Math.max(0,Math.min(max,s));}
        void setValue(int mins){seconds=mins*60;}
        protected void onDraw(Canvas c){super.onDraw(c);float cx=getWidth()/2f,cy=getHeight()/2f,r=Math.min(cx,cy)-20;
            p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(10);p.setColor(Color.rgb(20,57,105));c.drawCircle(cx,cy,r,p);
            p.setColor(Color.rgb(38,105,255));float sweep=360f*seconds/max;c.drawArc(cx-r,cy-r,cx+r,cy+r,-90,sweep,false,p);
            p.setStyle(Paint.Style.FILL);p.setTextAlign(Paint.Align.CENTER);p.setTypeface(Typeface.DEFAULT);p.setColor(Color.WHITE);p.setTextSize(34);
            long mm=seconds/60,ss=seconds%60;c.drawText(String.format(Locale.US,"%02d:%02d",mm,ss),cx,cy+8,p);p.setTextSize(10);p.setColor(Color.rgb(145,165,195));c.drawText("Study Time",cx,cy+32,p);
        }
    }

    void showSyllabus(){
        head("10th SSC Syllabus");
        LinearLayout chips=new LinearLayout(this);String[] c={"All","Science","Maths","Social"};for(int i=0;i<c.length;i++){TextView x=chip(c[i],i==0);chips.addView(x,new LinearLayout.LayoutParams(0,dp(36),1));if(i>0)((LinearLayout.LayoutParams)x.getLayoutParams()).setMargins(dp(4),0,0,0);}content.addView(chips);addGap(10);
        for(String s:SUBJECTS){
            LinearLayout p=card();TextView n=label(subjectIcon(s)+"  "+s,14);n.setTypeface(null,1);p.addView(n);
            p.addView(text("Prelims • "+subjectPct(s,"Prelims")+"%  •  "+doneCount(s,"Prelims")+"/"+items(s,"Prelims").size()+" chapters/topics",10,MUTED));
            ProgressBar bar=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);bar.setMax(100);bar.setProgress(subjectPct(s,"Prelims"));p.addView(bar,new LinearLayout.LayoutParams(-1,dp(7)));
            TextView open=clickable("Open subject  ›",10,PANEL2);open.setOnClickListener(v->showSubject(s));p.addView(open);
            content.addView(p);addGap(7);
        }
    }

    String subjectIcon(String s){if(s.contains("Math"))return "🧮";if(s.contains("Science"))return "⚗";if(s.contains("English"))return "📘";if(s.contains("Marathi"))return "📕";if(s.contains("Hindi"))return "📗";if(s.contains("Sanskrit"))return "ॐ";if(s.contains("History")||s.contains("Political")||s.contains("Geography"))return "🌍";return "📚";}

    void showSubject(String sub){
        head(sub);
        for(String e:exams()){
            ArrayList<String>a=items(sub,e);if(a.isEmpty())continue;
            TextView sec=label(e+(e.equals("I Unit Test")?"  •  COMPLETED":"")+"   "+subjectPct(sub,e)+"%",15);sec.setTypeface(null,1);content.addView(sec);addGap(4);
            for(String item:a){
                LinearLayout r=card();r.setOrientation(LinearLayout.HORIZONTAL);
                CheckBox cb=new CheckBox(this);cb.setChecked(sp.getBoolean(key(sub,e,item),false));cb.setText(item);cb.setTextColor(WHITE);cb.setTextSize(12);
                cb.setOnCheckedChangeListener((b,checked)->sp.edit().putBoolean(key(sub,e,item),checked).apply());r.addView(cb,new LinearLayout.LayoutParams(0,dp(58),1));
                content.addView(r);addGap(5);
            }
        }
    }

    void showPlan(){
        head("Study Plan");
        LinearLayout tabs=new LinearLayout(this);for(int i=0;i<3;i++){TextView c=chip(new String[]{"Daily","Weekly","Monthly"}[i],i==0);tabs.addView(c,new LinearLayout.LayoutParams(0,dp(38),1));if(i>0)((LinearLayout.LayoutParams)c.getLayoutParams()).setMargins(dp(4),0,0,0);}content.addView(tabs);addGap(12);
        TextView day=label("‹   Mon, 12 Oct 2026   ›",14);day.setGravity(Gravity.CENTER);content.addView(day);addGap(8);
        String[][] tasks={{"06:00 - 07:00","Maths","Completed",GREEN},{"07:00 - 08:00","English","Completed",GREEN},{"09:00 - 10:00","Science","Pending",MUTED},{"11:00 - 12:00","Social Science","Pending",MUTED},{"02:00 - 03:00","Marathi","Pending",MUTED},{"04:00 - 05:00","Revision","Pending",MUTED}};
        for(String[] x:tasks){LinearLayout r=card();r.setOrientation(LinearLayout.HORIZONTAL);r.addView(text("☐  "+x[0],10,MUTED),new LinearLayout.LayoutParams(dp(100),dp(45)));r.addView(label(x[1],12),new LinearLayout.LayoutParams(0,dp(45),1));r.addView(text(x[2],10,(int)x[3]),new LinearLayout.LayoutParams(dp(70),dp(45)));content.addView(r);addGap(5);}
        TextView add=clickable("＋ Add Task",12,BLUE);content.addView(add);add.setOnClickListener(v->showPlanEditor());
    }

    void showPlanEditor(){
        head("Edit Study Plan");content.addView(text("Flexible plan — no fixed clock times required. Maths stays every day for 60 minutes.",12,MUTED));
        for(String d:new String[]{"Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"}){EditText e=new EditText(this);e.setTextColor(WHITE);e.setHintTextColor(MUTED);e.setHint(d+" — subjects / duration");e.setBackground(stroke(PANEL2,LINE,12));e.setPadding(dp(12),0,dp(12),0);content.addView(e,new LinearLayout.LayoutParams(-1,dp(54)));addGap(6);}
        TextView save=clickable("Save plan",12,BLUE);content.addView(save);save.setOnClickListener(v->{Toast.makeText(this,"Study plan saved",Toast.LENGTH_SHORT).show();showPlan();});
    }

    void showExams(){
        head("Exams");
        LinearLayout tabs=new LinearLayout(this);for(int i=0;i<4;i++){TextView c=chip(new String[]{"All","Unit Test","Prelim","Board"}[i],i==0);tabs.addView(c,new LinearLayout.LayoutParams(0,dp(38),1));if(i>0)((LinearLayout.LayoutParams)c.getLayoutParams()).setMargins(dp(4),0,0,0);}content.addView(tabs);addGap(10);
        examCard("Unit Test 1","OVER","I Unit Test",GREEN);examCard("I Term Exam","Upcoming","I Term",GREEN);examCard("Preliminary Exam","Upcoming","Prelims",PURPLE);examCard("Board Exam","Not added","Board",ORANGE);
        TextView next=clickable("＋ Add / update next exam",12,BLUE);content.addView(next);next.setOnClickListener(v->showNextExam());
        TextView web=clickable("🌐 Search school timetable in browser",11,PANEL2);content.addView(web);web.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse("https://www.google.com/search?q="+Uri.encode("Model English School Dombivli East Std X SSC timetable")));startActivity(i);});
    }
    void examCard(String name,String status,String exam,int color){
        LinearLayout p=card();p.setOrientation(LinearLayout.HORIZONTAL);TextView icon=text("▣",22,color);p.addView(icon,new LinearLayout.LayoutParams(dp(42),dp(64)));
        LinearLayout mid=new LinearLayout(this);mid.setOrientation(LinearLayout.VERTICAL);mid.addView(label(name,13));mid.addView(text(exam+"  •  Study completion "+(exam.equals("Board")?0:pct(exam))+"%",10,MUTED));p.addView(mid,new LinearLayout.LayoutParams(0,dp(64),1));p.addView(text(status,9,color),new LinearLayout.LayoutParams(dp(70),dp(64)));content.addView(p);addGap(7);
    }

    void showNextExam(){
        head("Next Exam");
        EditText n=field("Exam name (I Term / Prelims)");n.setText(sp.getString("nextExamName",""));content.addView(n);addGap(7);
        EditText d=field("Date (example: 2026-10-15)");d.setText(sp.getString("nextExamDate",""));content.addView(d);addGap(10);
        TextView save=clickable("Save next exam",12,BLUE);content.addView(save);save.setOnClickListener(v->{sp.edit().putString("nextExamName",n.getText().toString()).putString("nextExamDate",d.getText().toString()).apply();showExams();});
    }
    EditText field(String hint){EditText e=new EditText(this);e.setTextColor(WHITE);e.setHintTextColor(MUTED);e.setHint(hint);e.setTextSize(13);e.setBackground(stroke(PANEL2,LINE,12));e.setPadding(dp(12),0,dp(12),0);e.setSingleLine(true);e.setLayoutParams(new LinearLayout.LayoutParams(-1,dp(55)));return e;}

    void showProgress(){
        head("Progress");
        LinearLayout tabs=new LinearLayout(this);TextView a=chip("Overview",true),b=chip("Subject Wise",false);tabs.addView(a,new LinearLayout.LayoutParams(0,dp(38),1));tabs.addView(b,new LinearLayout.LayoutParams(0,dp(38),1));((LinearLayout.LayoutParams)b.getLayoutParams()).setMargins(dp(5),0,0,0);content.addView(tabs);addGap(14);
        LinearLayout p=card();p.setGravity(Gravity.CENTER);RingView ring=new RingView(this);ring.setValue(pct("Prelims")*36/100);p.addView(ring,new LinearLayout.LayoutParams(dp(190),dp(190)));content.addView(p,new LinearLayout.LayoutParams(-1,dp(220)));addGap(10);
        TextView summary=label("Overall Course Progress     "+pct("Prelims")+"%",14);summary.setTypeface(null,1);content.addView(summary);addGap(5);
        for(String s:SUBJECTS){if(items(s,"Prelims").isEmpty())continue;LinearLayout r=card();r.setOrientation(LinearLayout.HORIZONTAL);r.addView(text(subjectIcon(s)+"  "+s,11,WHITE),new LinearLayout.LayoutParams(0,dp(44),1));r.addView(text(subjectPct(s,"Prelims")+"%",11,MUTED),new LinearLayout.LayoutParams(dp(45),dp(44)));content.addView(r);addGap(4);}
        TextView marks=clickable("＋ Enter marks & view exam analysis",11,BLUE);content.addView(marks);marks.setOnClickListener(v->marksDialog("Prelims"));
    }

    void marksDialog(String exam){
        LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);ArrayList<String> active=new ArrayList<>();
        for(String s:SUBJECTS)if(!items(s,exam).isEmpty()){active.add(s);LinearLayout r=new LinearLayout(this);r.addView(text(s,10,WHITE),new LinearLayout.LayoutParams(0,dp(45),1));EditText g=new EditText(this);g.setHint("got");g.setTextColor(WHITE);g.setInputType(2);g.setText(sp.getString("got_"+exam+"_"+s,""));r.addView(g,new LinearLayout.LayoutParams(dp(65),dp(45)));EditText m=new EditText(this);m.setHint("max");m.setTextColor(WHITE);m.setInputType(2);m.setText(sp.getString("max_"+exam+"_"+s,"100"));r.addView(m,new LinearLayout.LayoutParams(dp(60),dp(45)));l.addView(r);}
        new AlertDialog.Builder(this).setTitle(exam+" marks").setView(l).setPositiveButton("Save",(d,w)->{int idx=0;for(String s:active){LinearLayout r=(LinearLayout)l.getChildAt(idx++);EditText g=(EditText)r.getChildAt(1),m=(EditText)r.getChildAt(2);sp.edit().putString("got_"+exam+"_"+s,g.getText().toString()).putString("max_"+exam+"_"+s,m.getText().toString()).apply();}Toast.makeText(this,"Marks saved",Toast.LENGTH_SHORT).show();}).setNegativeButton("Cancel",null).show();
    }

    void showReminders(){
        head("Reminders");
        TextView en=label("Enable Reminders",13);content.addView(en);Switch sw=new Switch(this);sw.setChecked(sp.getBoolean("hourly",true));content.addView(sw);sw.setOnCheckedChangeListener((b,c)->{sp.edit().putBoolean("hourly",c).apply();scheduleHourly(c);});
        reminderRow("🔔","Study Reminder","Every 2 hours");reminderRow("⭐","Motivational Messages","Every hour");reminderRow("▣","Exam Alerts","Before exam dates");
        TextView custom=clickable("You can do it! Keep going! 💪   ›",11,PANEL2);content.addView(custom);custom.setOnClickListener(v->showReminderPicker());
    }
    void reminderRow(String icon,String a,String b){LinearLayout r=card();r.setOrientation(LinearLayout.HORIZONTAL);r.addView(text(icon,22,CYAN),new LinearLayout.LayoutParams(dp(45),dp(62)));LinearLayout m=new LinearLayout(this);m.setOrientation(LinearLayout.VERTICAL);m.addView(label(a,12));m.addView(text(b,10,MUTED));r.addView(m,new LinearLayout.LayoutParams(0,dp(62),1));r.addView(text("›",20,MUTED),new LinearLayout.LayoutParams(dp(25),dp(62)));content.addView(r);addGap(7);}
    void showReminderPicker(){new TimePickerDialog(this,(v,h,m)->{Calendar c=Calendar.getInstance();c.set(Calendar.HOUR_OF_DAY,h);c.set(Calendar.MINUTE,m);c.set(Calendar.SECOND,0);if(c.getTimeInMillis()<System.currentTimeMillis())c.add(Calendar.DAY_OF_YEAR,1);Intent i=new Intent(this,ReminderReceiver.class);PendingIntent pi=PendingIntent.getBroadcast(this,7,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);((AlarmManager)getSystemService(ALARM_SERVICE)).setRepeating(AlarmManager.RTC_WAKEUP,c.getTimeInMillis(),24*60*60*1000L,pi);Toast.makeText(this,"Daily reminder set",Toast.LENGTH_SHORT).show();},18,0,true).show();}
    void scheduleHourly(boolean on){AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE);PendingIntent pi=PendingIntent.getBroadcast(this,8,new Intent(this,ReminderReceiver.class),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);am.cancel(pi);if(on)am.setRepeating(AlarmManager.RTC_WAKEUP,System.currentTimeMillis()+3600000L,3600000L,pi);}
    void scheduleTimer(long end){AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE);Intent i=new Intent(this,TimerReceiver.class);PendingIntent pi=PendingIntent.getBroadcast(this,9,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);if(Build.VERSION.SDK_INT>=31&&!am.canScheduleExactAlarms())try{startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,Uri.parse("package:"+getPackageName())));return;}catch(Exception ignored){}if(Build.VERSION.SDK_INT>=23)try{am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,end,pi);}catch(Exception e){am.set(AlarmManager.RTC_WAKEUP,end,pi);}else am.set(AlarmManager.RTC_WAKEUP,end,pi);}
    void cancelTimer(){PendingIntent pi=PendingIntent.getBroadcast(this,9,new Intent(this,TimerReceiver.class),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);((AlarmManager)getSystemService(ALARM_SERVICE)).cancel(pi);}

    void showMath(){
        head("Math Hub");LinearLayout p=card();p.addView(label("🧮 Quick Calculator",16));EditText input=field("Example: (25+5)*2");p.addView(input);TextView result=label("Result: —",18);p.addView(result);TextView calc=clickable("Calculate",11,BLUE);p.addView(calc);content.addView(p);calc.setOnClickListener(v->{try{result.setText("Result: "+simpleCalc(input.getText().toString()));}catch(Exception e){result.setText("Result: Check expression");}});
        addGap(10);LinearLayout t=card();t.addView(label("Daily Maths method",15));t.addView(text("60 minutes every day\n20 min concept • 25 min problem solving • 15 min error review\nKeep an error notebook and re-solve wrong sums.",11,MUTED));content.addView(t);
    }
    double simpleCalc(String s)throws Exception{s=s.replace(" ","");if(s.isEmpty())throw new Exception();Stack<Double> nums=new Stack<>();Stack<Character> ops=new Stack<>();for(int i=0;i<s.length();){char c=s.charAt(i);if(Character.isDigit(c)||c=='.'){int j=i+1;while(j<s.length()&&(Character.isDigit(s.charAt(j))||s.charAt(j)=='.'))j++;nums.push(Double.parseDouble(s.substring(i,j)));i=j;}else if(c=='('){ops.push(c);i++;}else if(c==')'){while(!ops.empty()&&ops.peek()!='(')apply(nums,ops.pop());if(ops.empty())throw new Exception();ops.pop();i++;}else if("+-*/".indexOf(c)>=0){while(!ops.empty()&&ops.peek()!='('&&prec(ops.peek())>=prec(c))apply(nums,ops.pop());ops.push(c);i++;}else throw new Exception();}while(!ops.empty())apply(nums,ops.pop());return nums.pop();}
    int prec(char c){return(c=='+'||c=='-')?1:2;}void apply(Stack<Double>n,char o){double b=n.pop(),a=n.pop();n.push(o=='+'?a+b:o=='-'?a-b:o=='*'?a*b:a/b);}

    void showMore(){
        head("More");
        String[][] a={{"▣","Notes","notes"},{"📄","Previous Papers","papers"},{"🔗","Important Links","links"},{"☏","Doubt Help","help"},{"🏆","Achievements","ach"},{"☁","Backup","backup"}};
        for(int r=0;r<3;r++){LinearLayout row=new LinearLayout(this);for(int c=0;c<2;c++){int ix=r*2+c;LinearLayout b=action(a[ix][0],a[ix][1]);row.addView(b,new LinearLayout.LayoutParams(0,dp(82),1));if(c==0)((LinearLayout.LayoutParams)b.getLayoutParams()).setMargins(0,0,dp(8),dp(8));}content.addView(row);}
        addGap(10);LinearLayout p=card();p.addView(label("🏆 Progress, not perfection.",12));p.addView(text("You got this!",10,MUTED));content.addView(p);
        TextView settings=clickable("⚙  Settings",12,PANEL2);content.addView(settings);settings.setOnClickListener(v->showSettings());
    }
    void showSettings(){head("Settings");String[] a={"👤 Profile","📚 Syllabus & Portions","🌐 School Timetable","🎓 Classes / Coaching","▣ Exam Schedule","⚙ Study Preferences","🔔 Notifications","◐ Appearance (Dark Theme)","ℹ About"};for(String x:a){TextView b=clickable(x+"    ›",12,PANEL2);content.addView(b);addGap(5);if(x.contains("Syllabus"))b.setOnClickListener(v->showSyllabus());else if(x.contains("Exam"))b.setOnClickListener(v->showExams());else if(x.contains("Notifications"))b.setOnClickListener(v->showReminders());}}
}
