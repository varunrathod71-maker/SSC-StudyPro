package com.sscstudymanager;

import android.app.*;
import android.content.*;
import android.os.*;
import android.net.Uri;
import android.media.AudioAttributes;

public class TimerReceiver extends BroadcastReceiver {
    public void onReceive(Context c, Intent i) {
        NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        if(Build.VERSION.SDK_INT>=26){
            NotificationChannel ch=new NotificationChannel("studypro_timer","StudyPro Timer",NotificationManager.IMPORTANCE_HIGH);
            ch.setDescription("One hour study timer");
            ch.setSound(Uri.parse("android.resource://"+c.getPackageName()+"/"+R.raw.studypro_complete),
                    new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION).build());
            nm.createNotificationChannel(ch);
        }
        Intent open=new Intent(c,MainActivity.class);
        PendingIntent pi=PendingIntent.getActivity(c,1,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(c,"studypro_timer"):new Notification.Builder(c);
        b.setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
         .setContentTitle("StudyPro • 1 hour complete!")
         .setContentText("Great work! Take your break, then start again when you're ready.")
         .setAutoCancel(true).setContentIntent(pi);
        nm.notify(1001,b.build());
        c.getSharedPreferences("data",0).edit().remove("timerEnd").apply();
    }
}
