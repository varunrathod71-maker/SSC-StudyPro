package com.sscstudymanager;

import android.app.*;
import android.content.*;
import android.os.*;

public class ReminderReceiver extends BroadcastReceiver {
    public void onReceive(Context c,Intent i) {
        if(!c.getSharedPreferences("data",0).getBoolean("hourly",true)) return;
        NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        if(Build.VERSION.SDK_INT>=26){
            NotificationChannel ch=new NotificationChannel("studypro_motivation","StudyPro Motivation",NotificationManager.IMPORTANCE_DEFAULT);
            ch.setDescription("Hourly motivation");
            nm.createNotificationChannel(ch);
        }
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(c,"studypro_motivation"):new Notification.Builder(c);
        b.setSmallIcon(android.R.drawable.ic_dialog_info)
         .setContentTitle("StudyPro motivation")
         .setContentText("Keep going — one focused block today makes tomorrow easier. 💙")
         .setAutoCancel(true);
        nm.notify((int)(System.currentTimeMillis()%100000),b.build());
    }
}
