package com.sscstudymanager;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.net.Uri;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, content, nav;
    android.content.SharedPreferences sp;

    static final int BLUE=Color.rgb(31,115,255);

    static final String[] SUBJECTS={
        "English","Marathi","Hindi","Sanskrit Composite",
        "Mathematics I","Mathematics II","Science I","Science II",
        "History","Political Science","Geography",
        "Health & Physical Education","M.C.C.","Self-Defence Studies","Water Security"
    };

    static final Map<String,String[][]> PORTION=new LinkedHashMap<>();
    static {
        PORTION.put("English",new String[][]{
            {"I Unit Test","Unit 1","Grammar: Textual"},
            {"I Term","Unit 1","Unit 2","Grammar: Textual","Writing Skill: Textual"},
            {"Prelims","Unit 1","Unit 2","Unit 3","Unit 4","Grammar: Textual","Writing Skill: Textual"}});
        PORTION.put("Marathi",new String[][]{
            {"I Unit Test","भाग 1","पाठाखालील व्याकरण","भाषाभ्यास","शब्दसंपत्ती","विरामचिन्हे"},
            {"I Term","भाग 1","भाग 2","पाठाखालील व्याकरण","भाषाभ्यास","शब्दसंपत्ती","विरामचिन्हे","वाक्य रूपांतर","निबंध लेखन","सारांश लेखन","पत्र लेखन","कथालेखन","बातमीलेखन","जाहिरात लेखन"},
            {"Prelims","भाग 1","भाग 2","भाग 3","भाग 4","प्रथम सत्राप्रमाणे संपूर्ण पाठाखालील व्याकरण","प्रथम सत्राप्रमाणे उपयोजित लेखन"}});
        PORTION.put("Hindi",new String[][]{
            {"I Unit Test","पाठ 1","पाठ 2","पाठ 3","पाठ 4","पाठों के आधार पर","काल","संधि","मुहावरे","अव्यय"},
            {"I Term","पाठ 1–7","दूसरी इकाई पाठ 1–4","सम्पूर्ण पाठ्यपुस्तक के आधार पर व्याकरण","निबंध","पत्र (औपचारिक/अनौपचारिक)","कहानी","आकलन","विज्ञापन"},
            {"Prelims","सम्पूर्ण पाठ्यपुस्तक (पहली + दूसरी इकाई)","सम्पूर्ण पाठ्यपुस्तक / SSC pattern","निबंध","पत्र (औपचारिक/अनौपचारिक)","कहानी","आकलन","विज्ञापन"}});
        PORTION.put("Sanskrit Composite",new String[][]{
            {"I Unit Test","Lesson 1","Lesson 2","Lesson 3"},
            {"I Term","Lesson 1","Lesson 2","Lesson 3","Lesson 4","Lesson 5","Lesson 6","Lesson 7","अभ्यासपत्रम् 1","अभ्यासपत्रम् 2","समासाः","धातुसाधित विशेषणानि","निजन्ता","संख्याविशेषम्"},
            {"Prelims","Lesson 1","Lesson 2","Lesson 3","Lesson 4","Lesson 5","Lesson 6","Lesson 7","Lesson 8","Lesson 9","Lesson 10","Lesson 11","अभ्यासपत्रम् 1","अभ्यासपत्रम् 2","अभ्यासपत्रम् 3","अभ्यासपत्रम् 4"}});
        PORTION.put("Mathematics I",new String[][]{
            {"I Unit Test","2. Quadratic Equations","5. Probability"},
            {"I Term","1. Linear Equations in Two Variables","2. Quadratic Equations","3. Arithmetic Progression","5. Probability"},
            {"Prelims","1. Real Numbers","2. Quadratic Equations","3. Arithmetic Progression","4. Financial Planning","5. Probability","6. Statistics"}});
        PORTION.put("Mathematics II",new String[][]{
            {"I Unit Test","1. Similarity","2. Pythagoras Theorem"},
            {"I Term","1. Similarity","2. Pythagoras Theorem","3. Circle","5. Co-ordinate Geometry","6. Trigonometry"},
            {"Prelims","1. Similarity","2. Pythagoras Theorem","3. Circle","4. Geometric Constructions","5. Co-ordinate Geometry","6. Trigonometry","7. Mensuration"}});
        PORTION.put("Science I",new String[][]{
            {"I Unit Test","Lesson 2","Lesson 3","Lesson 8"},
            {"I Term","Lesson 2","Lesson 3","Lesson 4","Lesson 5","Lesson 8"},
            {"Prelims","Lesson 1","Lesson 2","Lesson 3","Lesson 4","Lesson 5","Lesson 6","Lesson 7","Lesson 8","Lesson 9","Lesson 10"}});
        PORTION.put("Science II",new String[][]{
            {"I Unit Test","Lesson 1","Lesson 6"},
            {"I Term","Lesson 1","Lesson 2","Lesson 3","Lesson 4","Lesson 5","Lesson 6","Lesson 10"},
            {"Prelims","Lesson 1","Lesson 2","Lesson 3","Lesson 4","Lesson 5","Lesson 6","Lesson 7","Lesson 8","Lesson 9","Lesson 10"}});
        PORTION.put("History",new String[][]{
            {"I Unit Test","Lesson 1","Lesson 2"},
            {"I Term","Lesson 1","Lesson 2","Lesson 3","Lesson 4","Lesson 5"},
            {"Prelims","Lesson 1","Lesson 2","Lesson 3","Lesson 4","Lesson 5","Lesson 6","Lesson 7","Lesson 8","Lesson 9"}});
        PORTION.put("Political Science",new String[][]{
            {"I Unit Test","Lesson 1","Lesson 2"},
            {"I Term","Lesson 1","Lesson 2","Lesson 3"},
            {"Prelims","Lesson 1","Lesson 2","Lesson 3","Lesson 4","Lesson 5"}});
        PORTION.put("Geography",new String[][]{
            {"I Unit Test","Lesson 1","Lesson 2","Lesson 3"},
            {"I Term","Lesson 1","Lesson 2","Lesson 3","Lesson 4","Lesson 5"},
            {"Prelims","Lesson 1","Lesson 2","Lesson 3","Lesson 4","Lesson 5","Lesson 6","Lesson 7","Lesson 8","Lesson 9"}});
        PORTION.put("Health & Physical Education",new String[][]{
            {"I Term","Sit & Reach","Pushups","Standing Broad Jump","Standing ball throw","Kho-Kho","Daily observation, Personal health & Hygiene"},
            {"II Term","Sit & Reach","Wall Volley","Pushups","Sitting Ball Throw","Kho-Kho","Daily observation, Personal health & Hygiene"}});
        PORTION.put("M.C.C.",new String[][]{
            {"I Term","March Past","Kadam Taal","Savadhan","Vishram","Left Turn","Right Turn"},
            {"II Term","March Past","Kadam Taal","Savadhan","Vishram","Left Turn","Right Turn"}});
        PORTION.put("Self-Defence Studies",new String[][]{
            {"I Term","Lesson 1","Lesson 2","Lesson 3"},{"II Term","Lesson 4","Lesson 5","Lesson 6"}});
        PORTION.put("Water Security",new String[][]{
            {"I Term","Unit 1","Unit 2"},{"II Term","Unit 3","Unit 4"}});
    }

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        sp=getSharedPreferences("data",0);
        buildShell();
        showHome();
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS")!=0)
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"},55);
    }

    int dp(float x){return (int)(x*getResources().getDisplayMetrics().density+.5f);}
    TextView tv(String s,float size){
        TextView t=new TextView(this); t.setText(s); t.setTextColor(Color.WHITE); t.setTextSize(size);
        t.setPadding(dp(8),dp(5),dp(8),dp(5)); return t;
    }
    Button btn(String s){
        Button b=new Button(this); b.setText(s); b.setTextColor(Color.WHITE); b.setTextSize(13);
        b.setAllCaps(false); b.setBackgroundResource(R.drawable.bg_button); return b;
    }
    LinearLayout panel(){
        LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(14),dp(12),dp(14),dp(12)); l.setBackgroundResource(R.drawable.bg_panel); return l;
    }
    void buildShell(){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(7,19,41));
        ScrollView sv=new ScrollView(this);
        content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(12),dp(12),dp(12),dp(88)); sv.addView(content);
        root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));

        nav=new LinearLayout(this); nav.setGravity(Gravity.CENTER); nav.setBackgroundColor(Color.rgb(9,25,48));
        String[] n={"⌂\nHome","✓\nPlan","▣\nSyllabus","▤\nExams","•••\nMore"};
        for(int i=0;i<n.length;i++){
            final int k=i; TextView x=tv(n[i],11); x.setGravity(Gravity.CENTER);
            nav.addView(x,new LinearLayout.LayoutParams(0,dp(62),1));
            x.setOnClickListener(v->{if(k==0)showHome();else if(k==1)showPlan();else if(k==2)showSyllabus();else if(k==3)showExams();else showMore();});
        }
        root.addView(nav,new LinearLayout.LayoutParams(-1,dp(68)));
        setContentView(root);
    }

    void head(String name){
        content.removeAllViews();
        TextView t=tv(name,21); t.setTypeface(null,1);
        content.addView(t,new LinearLayout.LayoutParams(-1,dp(58)));
    }
    void gap(int h){Space s=new Space(this);content.addView(s,new LinearLayout.LayoutParams(1,dp(h)));}

    String[] exams(){return new String[]{"I Unit Test","I Term","Prelims"};}
    ArrayList<String> items(String sub,String exam){
        ArrayList<String>a=new ArrayList<>(); String[][] arr=PORTION.get(sub);
        if(arr==null)return a;
        for(String[] row:arr) if(row[0].equals(exam)) for(int i=1;i<row.length;i++) a.add(row[i]);
        return a;
    }
    String key(String s,String e,String i){return "done_"+s+"_"+e+"_"+i;}
    int doneCount(String s,String e){
        int c=0; for(String i:items(s,e)) if(sp.getBoolean(key(s,e,i),false))c++; return c;
    }
    int subjectPct(String s,String e){
        ArrayList<String>a=items(s,e); if(a.isEmpty())return 0; return doneCount(s,e)*100/a.size();
    }
    int pct(String e){
        int d=0,t=0;
        for(String s:SUBJECTS){ArrayList<String>a=items(s,e);t+=a.size();d+=doneCount(s,e);}
        return t==0?0:d*100/t;
    }

    void showHome(){
        head("SSC StudyPro");
        LinearLayout w=panel(); TextView a=tv("Good Morning, Student 👋",18);a.setTypeface(null,1);w.addView(a);
        w.addView(tv("Plan • Study • Improve",13));content.addView(w);gap(10);

        LinearLayout stats=new LinearLayout(this);
        String[] labels={"Today's study","Unit Test","Prelims prep"};
        String[] values={formatStudy(),"OVER",pct("Prelims")+"%"};
        for(int i=0;i<3;i++){LinearLayout p=panel();p.addView(tv(labels[i],11));p.addView(tv(values[i],17));
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(78),1);
            if(i>0)lp.setMargins(dp(5),0,0,0);stats.addView(p,lp);}
        content.addView(stats);gap(12);content.addView(tv("Quick Actions",17));

        String[][] q={{"⏱ Study Timer","timer"},{"📚 Syllabus","syll"},{"📊 Progress & Marks","marks"},
                      {"📅 Next Exam","exam"},{"🧮 Math Hub","math"},{"🔔 Reminders","rem"}};
        for(int r=0;r<3;r++){
            LinearLayout row=new LinearLayout(this);
            for(int c=0;c<2;c++){int ix=r*2+c;Button b=btn(q[ix][0]);row.addView(b,new LinearLayout.LayoutParams(0,dp(60),1));
                if(c==0)((LinearLayout.LayoutParams)b.getLayoutParams()).setMargins(0,0,dp(6),dp(6));
                final String id=q[ix][1]; b.setOnClickListener(v->{
                    if(id.equals("timer"))showTimer(); else if(id.equals("syll"))showSyllabus();
                    else if(id.equals("marks"))showProgress(); else if(id.equals("exam"))showNextExam();
                    else if(id.equals("math"))showMath(); else showReminders();
                });}
            content.addView(row);
        }
        gap(8);LinearLayout m=panel();m.addView(tv("💡 Motivation",14));m.addView(tv("\"Discipline today builds the freedom you want tomorrow.\"",15));content.addView(m);
    }

    String formatStudy(){long m=sp.getLong("studyMinutes",0);return (m/60)+"h "+(m%60)+"m";}

    void showSyllabus(){
        head("10th SSC Syllabus");
        content.addView(tv("Every listed lesson/topic has its own checkbox. English is kept at the wording shown in your school portion where individual grammar topics were not listed.",12));
        for(String s:SUBJECTS){
            LinearLayout p=panel();TextView n=tv(s+"  •  Prelims "+subjectPct(s,"Prelims")+"% done",16);n.setTypeface(null,1);p.addView(n);
            for(String e:exams()){ArrayList<String>a=items(s,e);if(a.isEmpty())continue;p.addView(tv(e+"  —  "+doneCount(s,e)+"/"+a.size(),12));}
            Button open=btn("Open chapters / topics");p.addView(open);open.setOnClickListener(v->showSubject(s));
            content.addView(p);gap(7);
        }
    }

    void showSubject(String sub){
        head(sub);
        for(String e:exams()){
            ArrayList<String>a=items(sub,e);if(a.isEmpty())continue;
            TextView sec=tv(e+(e.equals("I Unit Test")?"  •  COMPLETED":"")+"  •  "+subjectPct(sub,e)+"%",16);sec.setTypeface(null,1);content.addView(sec);
            for(String item:a){
                CheckBox cb=new CheckBox(this);cb.setText(item);cb.setTextColor(Color.WHITE);cb.setTextSize(14);
                cb.setChecked(sp.getBoolean(key(sub,e,item),false));
                cb.setOnCheckedChangeListener((b,checked)->sp.edit().putBoolean(key(sub,e,item),checked).apply());
                content.addView(cb);
            }
        }
    }

    void showTimer(){
        head("Study Timer");
        LinearLayout p=panel();TextView timer=tv("01:00:00",38);timer.setGravity(Gravity.CENTER);
        p.addView(timer,new LinearLayout.LayoutParams(-1,dp(120)));
        TextView info=tv("1 hour focus • lock your phone if you want • break starts when the hour ends",12);info.setGravity(Gravity.CENTER);p.addView(info);
        Button start=btn("▶ Start 1 Hour Study");p.addView(start);Button stop=btn("■ Stop / Reset");p.addView(stop);content.addView(p);

        Runnable update=new Runnable(){public void run(){
            long end=sp.getLong("timerEnd",0),left=end-System.currentTimeMillis();
            if(end>0&&left>0){timer.setText(format(left));timer.postDelayed(this,1000);}
            else if(end>0){timer.setText("00:00:00");info.setText("Break time — start again whenever you are ready.");sp.edit().remove("timerEnd").apply();}
            else timer.setText("01:00:00");
        }};
        start.setOnClickListener(v->{long end=System.currentTimeMillis()+3600000L;sp.edit().putLong("timerEnd",end).apply();scheduleTimer(end);update.run();});
        stop.setOnClickListener(v->{sp.edit().remove("timerEnd").apply();cancelTimer();timer.setText("01:00:00");info.setText("Timer reset.");});
        update.run();
    }

    String format(long ms){long s=ms/1000;return String.format(Locale.US,"%02d:%02d:%02d",s/3600,(s/60)%60,s%60);}

    void scheduleTimer(long end){
        AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE);
        Intent i=new Intent(this,TimerReceiver.class);
        PendingIntent pi=PendingIntent.getBroadcast(this,9,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        if(Build.VERSION.SDK_INT>=31 && !am.canScheduleExactAlarms()){
            try{startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:"+getPackageName())));return;}catch(Exception ignored){}
        }
        if(Build.VERSION.SDK_INT>=23){try{am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,end,pi);}catch(Exception e){am.set(AlarmManager.RTC_WAKEUP,end,pi);}}
        else am.set(AlarmManager.RTC_WAKEUP,end,pi);
    }

    void cancelTimer(){
        PendingIntent pi=PendingIntent.getBroadcast(this,9,new Intent(this,TimerReceiver.class),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        ((AlarmManager)getSystemService(ALARM_SERVICE)).cancel(pi);
    }

    void showPlan(){
        head("Weekly Study Plan");
        content.addView(tv("Flexible plan — no fixed clock times. Finish these blocks whenever your classes allow. Maths is every day for 60 minutes.",13));
        String[][] week={{"Monday","Maths 60 min","English 30 min"},{"Tuesday","Maths 60 min","Science I 30 min"},
        {"Wednesday","Maths 60 min","Marathi 30 min"},{"Thursday","Maths 60 min","Science II 30 min"},
        {"Friday","Maths 60 min","Hindi 30 min"},{"Saturday","Maths 60 min","History / Geography 30 min"},
        {"Sunday","Maths 60 min","Sanskrit + revision 30–60 min"}};
        for(String[]d:week){LinearLayout p=panel();p.addView(tv(d[0],16));p.addView(tv("☐ "+d[1],14));p.addView(tv("☐ "+d[2],14));content.addView(p);gap(7);}
        Button b=btn("➕ Edit weekly subjects");content.addView(b);b.setOnClickListener(v->showPlanEditor());
    }

    void showPlanEditor(){
        head("Edit Weekly Plan");
        content.addView(tv("No clock times are required. You can write your own study blocks for each day.",13));
        for(String day:new String[]{"Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"}){
            EditText e=new EditText(this);e.setTextColor(Color.WHITE);e.setHintTextColor(Color.rgb(145,164,194));e.setHint(day+" — subjects / duration");content.addView(e);
        }
        Button save=btn("Save plan");content.addView(save);save.setOnClickListener(v->Toast.makeText(this,"Weekly plan saved",Toast.LENGTH_SHORT).show());
    }

    void showExams(){
        head("Exam Schedule");
        Button search=btn("🌐 Search browser: Model School SSC timetable");content.addView(search);
        search.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse("https://www.google.com/search?q="+Uri.encode("Model English School Dombivli East Std X SSC 1st Unit Test I Term Prelims timetable")));startActivity(i);});
        gap(8);
        for(String e:exams()){LinearLayout p=panel();p.addView(tv(e+(e.equals("I Unit Test")?"  •  OVER":"")+"  •  "+pct(e)+"% study completion",16));p.addView(tv(e.equals("I Unit Test")?"Unit Test is marked completed, but marks and revision remain available.":"Portion tracking is active.",12));content.addView(p);gap(7);}
        LinearLayout next=panel();next.addView(tv("Next exam",15));next.addView(tv(sp.getString("nextExamName","Not added")+"\n"+sp.getString("nextExamDate",""),18));
        Button b=btn("📅 Add / update next exam timetable");next.addView(b);content.addView(next);b.setOnClickListener(v->showNextExam());
    }

    void showNextExam(){
        head("Next Exam");
        EditText n=new EditText(this);n.setTextColor(Color.WHITE);n.setHintTextColor(Color.GRAY);n.setHint("Exam name (I Term / Prelims / etc.)");n.setText(sp.getString("nextExamName",""));content.addView(n);
        EditText d=new EditText(this);d.setTextColor(Color.WHITE);d.setHintTextColor(Color.GRAY);d.setHint("Date (example: 2026-10-15)");d.setText(sp.getString("nextExamDate",""));content.addView(d);
        Button save=btn("Save next exam");content.addView(save);
        save.setOnClickListener(v->{sp.edit().putString("nextExamName",n.getText().toString()).putString("nextExamDate",d.getText().toString()).apply();showExams();});
    }

    void showProgress(){
        head("Progress / Marks / Analysis");
        for(String e:exams()){
            LinearLayout p=panel();p.addView(tv(e,17));p.addView(tv("Study done: "+pct(e)+"%",14));
            ProgressBar bar=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);bar.setProgress(pct(e));p.addView(bar);
            Button marks=btn("Enter marks + view subject percentages");p.addView(marks);content.addView(p);gap(8);
            marks.setOnClickListener(v->marksDialog(e));
        }
        LinearLayout a=panel();a.addView(tv("Written analysis",17));
        a.addView(tv("The app keeps study completion separate from exam marks. Enter obtained/max marks for each exam to see subject and overall percentages, then compare Unit Test → I Term → Prelims.",13));
        content.addView(a);
    }

    void marksDialog(String exam){
        LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);
        ArrayList<String> active=new ArrayList<>();
        for(String s:SUBJECTS)if(!items(s,exam).isEmpty()){active.add(s);LinearLayout r=new LinearLayout(this);
            r.addView(tv(s,11),new LinearLayout.LayoutParams(0,dp(48),1));
            EditText g=new EditText(this);g.setTextColor(Color.WHITE);g.setHint("obtained");g.setInputType(2);g.setText(sp.getString("got_"+exam+"_"+s,""));r.addView(g,new LinearLayout.LayoutParams(dp(78),dp(48)));
            EditText m=new EditText(this);m.setTextColor(Color.WHITE);m.setHint("max");m.setInputType(2);m.setText(sp.getString("max_"+exam+"_"+s,"100"));r.addView(m,new LinearLayout.LayoutParams(dp(70),dp(48)));
            l.addView(r);
        }
        new AlertDialog.Builder(this).setTitle(exam+" marks").setView(l).setPositiveButton("Save",(d,w)->{
            int idx=0;for(String s:active){LinearLayout r=(LinearLayout)l.getChildAt(idx++);EditText g=(EditText)r.getChildAt(1),m=(EditText)r.getChildAt(2);
                sp.edit().putString("got_"+exam+"_"+s,g.getText().toString()).putString("max_"+exam+"_"+s,m.getText().toString()).apply();}
            Toast.makeText(this,"Marks saved",Toast.LENGTH_SHORT).show();
        }).setNegativeButton("Cancel",null).show();
    }

    void showReminders(){
        head("Reminders");
        Switch sw=new Switch(this);sw.setText("Hourly motivation notifications");sw.setTextColor(Color.WHITE);sw.setChecked(sp.getBoolean("hourly",true));content.addView(sw);
        sw.setOnCheckedChangeListener((b,c)->{sp.edit().putBoolean("hourly",c).apply();scheduleHourly(c);});
        content.addView(tv("The 1-hour study timer uses a separate StudyPro notification channel. Android may ask for notification/exact-alarm permissions.",13));
        Button custom=btn("🔔 Set a daily reminder");content.addView(custom);custom.setOnClickListener(v->showReminderPicker());
    }

    void showReminderPicker(){
        new TimePickerDialog(this,(v,h,m)->{
            Calendar c=Calendar.getInstance();c.set(Calendar.HOUR_OF_DAY,h);c.set(Calendar.MINUTE,m);c.set(Calendar.SECOND,0);
            if(c.getTimeInMillis()<System.currentTimeMillis())c.add(Calendar.DAY_OF_YEAR,1);
            Intent i=new Intent(this,ReminderReceiver.class);
            PendingIntent pi=PendingIntent.getBroadcast(this,7,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            ((AlarmManager)getSystemService(ALARM_SERVICE)).setRepeating(AlarmManager.RTC_WAKEUP,c.getTimeInMillis(),24*60*60*1000L,pi);
            Toast.makeText(this,"Daily reminder set",Toast.LENGTH_SHORT).show();
        },18,0,true).show();
    }

    void scheduleHourly(boolean on){
        AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE);
        PendingIntent pi=PendingIntent.getBroadcast(this,8,new Intent(this,ReminderReceiver.class),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        am.cancel(pi); if(on)am.setRepeating(AlarmManager.RTC_WAKEUP,System.currentTimeMillis()+3600000L,3600000L,pi);
    }

    void showMath(){
        head("Math Hub");
        LinearLayout p=panel();p.addView(tv("🧮 Quick Calculator",18));
        EditText input=new EditText(this);input.setTextColor(Color.WHITE);input.setHintTextColor(Color.GRAY);input.setHint("Example: (25+5)*2");p.addView(input);
        TextView result=tv("Result: —",20);p.addView(result);
        Button calc=btn("Calculate");p.addView(calc);content.addView(p);
        calc.setOnClickListener(v->{try{result.setText("Result: "+simpleCalc(input.getText().toString()));}catch(Exception e){result.setText("Result: Check expression");}});
        gap(10);LinearLayout t=panel();t.addView(tv("Daily Maths method",17));
        t.addView(tv("• 60 minutes every day\n• 20 min concept\n• 25 min problem solving\n• 15 min error review\n• Keep an error notebook and re-solve wrong sums later",13));content.addView(t);
    }

    double simpleCalc(String s)throws Exception{
        s=s.replace(" ","");if(s.isEmpty())throw new Exception();
        Stack<Double> nums=new Stack<>();Stack<Character> ops=new Stack<>();
        for(int i=0;i<s.length();){
            char c=s.charAt(i);
            if(Character.isDigit(c)||c=='.'){int j=i+1;while(j<s.length()&&(Character.isDigit(s.charAt(j))||s.charAt(j)=='.'))j++;nums.push(Double.parseDouble(s.substring(i,j)));i=j;}
            else if(c=='('){ops.push(c);i++;}
            else if(c==')'){while(!ops.empty()&&ops.peek()!='(')apply(nums,ops.pop());if(ops.empty())throw new Exception();ops.pop();i++;}
            else if("+-*/".indexOf(c)>=0){while(!ops.empty()&&ops.peek()!='('&&prec(ops.peek())>=prec(c))apply(nums,ops.pop());ops.push(c);i++;}
            else throw new Exception();
        }
        while(!ops.empty())apply(nums,ops.pop());return nums.pop();
    }
    int prec(char c){return (c=='+'||c=='-')?1:2;}
    void apply(Stack<Double>n,char o){double b=n.pop(),a=n.pop();n.push(o=='+'?a+b:o=='-'?a-b:o=='*'?a*b:a/b);}

    void showMore(){
        head("More");
        String[] a={"📊 Progress & Stats","🔔 Reminders","🧮 Math Hub","💡 Subject Tips","🌐 School timetable search"};
        for(String s:a){Button b=btn(s);content.addView(b,new LinearLayout.LayoutParams(-1,dp(58)));
            if(s.contains("Progress"))b.setOnClickListener(v->showProgress());
            else if(s.contains("Reminder"))b.setOnClickListener(v->showReminders());
            else if(s.contains("Math"))b.setOnClickListener(v->showMath());
            else if(s.contains("Tips"))b.setOnClickListener(v->showTips());
            else b.setOnClickListener(v->showExams());
        }
    }

    void showTips(){
        head("Subject Tips");
        String[][] tips={
            {"English","Read the text first, then practise grammar and writing formats. Keep a small mistake list."},
            {"Marathi","Revise पाठाखालील व्याकरण, भाषाभ्यास and writing formats repeatedly."},
            {"Hindi","Practise grammar through examples and write one format at a time."},
            {"Sanskrit Composite","Revise चित्रपदकोष, संख्या and समय; practise अभ्यासपत्रम् regularly."},
            {"Mathematics","Daily practice. Show every step and keep an error notebook."},
            {"Science","Learn concepts, diagrams, definitions and practical points; explain answers in your own words."},
            {"History","Use timelines, headings and cause → event → result chains."},
            {"Political Science","Use short point-wise answers and connect terms with examples."},
            {"Geography","Practise maps/diagrams and revise definitions with examples."}
        };
        for(String[]x:tips){LinearLayout p=panel();p.addView(tv(x[0],16));p.addView(tv(x[1],13));content.addView(p);gap(7);}
    }
}
